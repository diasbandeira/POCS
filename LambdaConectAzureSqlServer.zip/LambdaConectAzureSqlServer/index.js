const sql = require('mssql');
async function connectToAzureSQL() {
    try{
        const config = {
            user: 'prime_johnrichardbi',
            password: 'P@s%&$1bisystem',
            server: 'primebuildersqldb.database.windows.net',
            database: 'John_Richard',
            options: {
                encrypt: true,
                enableArithAbort: true,
                trustServerCertificate: false
            }
        }

        const pool = await sql.connect(config);
        const result = await pool.request().query('SELECT TOP (1) * FROM [dbo].[ENTREGA_RETIRADA]');
        const records = result.recordset;
        console.log(records);
        sql.close();

    }catch(err){
        console.error('Erro ao conectar a base de dados ' + err);
    }    
}

connectToAzureSQL();