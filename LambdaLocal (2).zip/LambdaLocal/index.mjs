import connectToAzureSQL from './connection.js';
const responseMessage = await connectToAzureSQL(Promotor);
export const handler = async (event) => {
  const {Promotor} = event;
 

  return {
    statusCode: 200,
    body: {
        message: responseMessage,
    },
  };
};

const simulateEvent = async () => {
  const event = {
    "Promotor" : "ANDRE"
  }

  try {
    const result = await handler(event);
    console.log('result: ', result);
  } catch(err){
    console.log('Error: ', err);
  }
}

simulateEvent();




// // index.js
// // Simula uma função Lambda
// //import connectToAzureSQL from './connection';
// const connectToAzureSQL = require('./connection.js');

// exports.handler = async (event) => {
//   console.log("Evento recebido:", JSON.stringify(event, null, 2));
  
//   // Processa o evento (neste exemplo, apenas retornamos uma mensagem)
//   const {Promotor} = event;
//   const responseMessage = await connectToAzureSQL(Promotor);

//   // Retorna a resposta
//   return {
//       statusCode: 200,
//       body: JSON.stringify({
//           message: responseMessage,
//       }),
//   };
// };

// // // Para simular a execução local
// // if (require.main === module) {
// //   const event = {    
// //         "Promotor": "ANDRE",
// //         "Supervisor": "Douglas Carvalho",
// //         "Status": "Inativo",
// //         "Inicio":"2024-10-01",
// //         "Fim":"2024-10-16"
// //     }; // Simulando um evento
// //   exports.handler(event)
// //       .then(response => {
// //           console.log("Resposta:", response);
// //       })
// //       .catch(error => {
// //           console.error("Erro:", error);
// //       });
// // }
