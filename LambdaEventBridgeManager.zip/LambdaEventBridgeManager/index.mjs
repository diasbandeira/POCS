import {}

export const handler = async (event) => {
  const {Promotor} = event;

  return {
    statusCode: 200,
    body: {
        message: JSON.stringify('teste'),
    },
  };
};

const simulateEvent = async () => {
  const event = {
    "Promotor" : "PEDRO H. SANTOS PRIME SYSTEMS"
  }

  try {
    const result = await handler(event);
    console.log('result: ', result);
  } catch(err){
    console.log('Error: ', err);
  }
}

simulateEvent();



import { SchedulerClient, CreateScheduleCommand, DeleteScheduleCommand } from "@aws-sdk/client-scheduler";
import { v4 as uuidv4 } from "uuid";

const REGION = "us-east-2";
const LAMBDA

export const handler = async (event) => {
  console.log("event: ", event);
  // TODO implement
  const response = {
    statusCode: 200,
    body: JSON.stringify('Hello from Lambda!'),
  };
  return response;
};
