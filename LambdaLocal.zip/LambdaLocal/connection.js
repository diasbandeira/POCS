const sql = require('mssql');

const connectToAzureSQL = async (promotor) => {
    try{
        const config = {
            user: 'adm.azure',
            password: 'qwe123!@#',
            server: 'primebuildersqldb.database.windows.net',
            database: 'ABTM',
            options: {
                encrypt: true,
                enableArithAbort: true,
                trustServerCertificate: false
            }
        }

        const pool = await sql.connect(config);
        const result = await pool.request().query(`SELECT agenda.ID_AGENDA, agenda.DIA_SEMANA, agenda.REDE, agenda.DESTINO, agenda.EMPRESA_VT, agenda.LINHA_VT, agenda.VALOR, agenda.TIPO, agenda.DATA_INICIO, agenda.DATA_FIM   FROM [dbo].[ABTM_VT] vt  left join [dbo].[ABTM_VT_AGENDA] agenda on agenda.ID_AGENDA = vt.ID_AGENDA  where vt.PROMOTOR = '${promotor}'`);
        const records = result.recordset;
        sql.close();
        return records;
        

    }catch(err){
        console.error('Erro ao conectar a base de dados ' + err);
    }    
};

// Exporta a função para ser usada em outros arquivos
module.exports = connectToAzureSQL;
